/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

void main()
{
    char ch;
    int num;
    float d;
     printf("Enter any character\n");
     scanf("%c",&ch);
    printf("Enter any number\n");
   scanf("%d",&num);
    printf("Enter any decimal number\n");
    scanf("%f",&d);
    printf("%c \n",ch);
    printf("%d \n",num);
    printf("%f \n",d);
}
