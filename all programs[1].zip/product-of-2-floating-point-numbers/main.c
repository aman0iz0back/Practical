/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
    #include <stdio.h>

void main()
{
    float a,b;
    printf("Enter first floating point number\n");
    scanf("%f",&a);
    printf("Enter second floating point number\n");
    scanf("%f",&b);
    printf("Product of numbers=%f",a*b);
    
}
