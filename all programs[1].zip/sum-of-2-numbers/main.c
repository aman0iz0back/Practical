#include<stdio.h>
void main()
{
    int a,b,sum;
    printf("Enter first number\n");
    scanf("%d",&a);
    printf("Enter second number\n");
    scanf("%d",&b);
    printf("Sum of 2 numbers is %d",a+b);
}